package com.pawana.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.pawana.dao.PatientDao;
import com.pawana.test.PatientBean;




@Controller
public class PatientController {
	@Autowired
	private PatientDao dao;
	@RequestMapping("/PatientForm")
	public ModelAndView showform(){
		return new ModelAndView("patientform","command",new PatientBean());
	}
	
	@RequestMapping(value="/save",method = RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("patient") PatientBean patient) {
		dao.save(patient);
		
		return new ModelAndView("result","message", "sucussfully completd");
		
	}
}
