package com.pawana.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pawana.test.PatientBean;

@Repository
@Transactional
public class PatientDao {
	@Autowired
	private SessionFactory session;

	public void save(PatientBean patient) {
		
		session.getCurrentSession().saveOrUpdate(patient);
	}

}